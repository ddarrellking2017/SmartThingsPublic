sudo python3 tool.py wakeup > wakeup_log.log
